package com.app.custome_exception;

@SuppressWarnings("serial")
public class StockCustomeExc extends Exception {
	public StockCustomeExc(String msg) {
		super(msg);
	}
}
