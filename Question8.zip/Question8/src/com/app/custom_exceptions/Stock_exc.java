package com.app.custom_exceptions;

public class Stock_exc extends Exception {
	
	public Stock_exc(String errMsg) {
		super(errMsg);
	}

}
