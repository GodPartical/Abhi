package com.app.custom_exceptions;

public class InsufficiantQuantityExc extends Stock_exc {
	public InsufficiantQuantityExc(String errMsg)
	{
		super(errMsg);
	}

}
