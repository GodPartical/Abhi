package bank;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Bank {
	
	public static void main(String[] args) {
		
		 String fileName = "D:\\lab java practice\\Bank\\src\\bank\\Jan2023.txt";
	        double sumOfDeposits = 0.0;
	        double maxDepositAmount = 0.0;
	        double shoppingExpenses = 0.0;
	        double maxWithdrawalAmount = 0.0;
	        String maxWithdrawalDate = "";

	        try (BufferedReader buffer = new BufferedReader(new FileReader(fileName))) {
	            String line = buffer.readLine(); 

	            while ((line = buffer.readLine()) != null) {
	                String[] values = line.split(",");
	                String transactionDate = values[0];
	                String narration = values[1];
	                double withdrawalAmount = Double.parseDouble(values[2]);
	                double depositAmount = Double.parseDouble(values[3]);

	                // Sum  deposits
	                sumOfDeposits += depositAmount;

	                // Max deposit 
	                if (depositAmount > maxDepositAmount) {
	                    maxDepositAmount = depositAmount;
	                }

	                // sum of withdrawals for shopping
	                if (narration.toLowerCase().contains("shopping")) {
	                    shoppingExpenses += withdrawalAmount;
	                }

	                // Date for which maximum amount withdrawn
	                if (withdrawalAmount > maxWithdrawalAmount) {
	                    maxWithdrawalAmount = withdrawalAmount;
	                    maxWithdrawalDate = transactionDate;
	                }
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	        System.out.println("Sum of all deposits = " + sumOfDeposits);
	        System.out.println("Max deposit amount = " + maxDepositAmount);
	        System.out.println("Shopping expenses = " + shoppingExpenses);
	        System.out.println("Date on which max amount withdrawn = " + maxWithdrawalDate);

}
}
