package vaildation;

import core.Status;
import core.TasksAttribute;

import java.time.LocalDate;

public class vaildation {
    public static int  taskId= 1;

    //  private String taskName;
    //    private String desc;
    //    private LocalDate taskDate;
    //    private Status status;
    //    private boolean active;
    
    //create a taskAttribute for the calling the constructore
    public static TasksAttribute createTask (String taskName,String desc , String date, String status ){
        LocalDate d =dateParsing(date); //calling the dateParsing(date) method
        Status a = enumParsing(status); //calling the enumParsing(status) method
        return new TasksAttribute(taskId++,taskName,desc,d,a,true);
    }
    
    // method for the convert string to LocalDate
    public static LocalDate dateParsing(String date ){
        return LocalDate.parse(date);
    }
    
    // method for the convert the  String to enum using valueOf()  method
    public static Status enumParsing (String enums)
    {
        return Status.valueOf(enums.toUpperCase());
    }
    
    public static boolean cheackActive (Status a){
        if(Status.PENDING == a){
            return true;
        }
        return false;
    }

}
