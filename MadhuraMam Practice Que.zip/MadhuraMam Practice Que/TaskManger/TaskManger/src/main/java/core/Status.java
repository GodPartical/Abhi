package core;

public enum Status {
        COMPLETED,PENDING,IN_PROGRESS;
}
