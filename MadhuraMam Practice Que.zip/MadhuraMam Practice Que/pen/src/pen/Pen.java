package pen;

import java.time.LocalDate;

public class Pen {
	
/*ID (unique identifier for each Pen, should be generated automatically)
	b.	Brand (Example:  Cello, Parker, Reynolds etc.)
	c.	Color
	d.	InkColor
	e.	Material (Example: Plastic, Alloy Steel, Metal etc.)
	f.	Stock (Available quantity)
	g.	Stock Update Date (it changed every time when admin update stock or user order executed)
	h.	Stock Listing Date (date on which product is added to site for sale)
	i.	Price (in INR) 
	j.	Discounts (in percentage)
*/
	private static int counter;
	private int id;
	private String brand;
	private String inkColor;
	private String meterial;
	private int stock;
	private LocalDate stockUpdateDate;
	private LocalDate stockListingDate;
	private double price;
	private double discount;
	
	//constr for the assigning and calling from object
public Pen(String brand, String inkColor, String meterial, int stock, LocalDate stockUpdateDate,
		LocalDate stockListingDate, double price, double discount) {
	super();
	this.id=++counter;
	this.brand = brand;
	this.inkColor = inkColor;
	this.meterial = meterial;
	this.stock = stock;
	this.stockUpdateDate = stockUpdateDate;
	this.stockListingDate = stockListingDate;
	this.price = price;
	this.discount = discount;
	
	
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getBrand() {
	return brand;
}

public void setBrand(String brand) {
	this.brand = brand;
}

public String getInkColor() {
	return inkColor;
}

public void setInkColor(String inkColor) {
	this.inkColor = inkColor;
}

public String getMeterial() {
	return meterial;
}

public void setMeterial(String meterial) {
	this.meterial = meterial;
}

public int getStock() {
	return stock;
}

public void setStock(int stock) {
	this.stock = stock;
}

public LocalDate getStockUpdateDate() {
	return stockUpdateDate;
}

public void setStockUpdateDate(LocalDate stockUpdateDate) {
	this.stockUpdateDate = stockUpdateDate;
}

public LocalDate getStockListingDate() {
	return stockListingDate;
}

public void setStockListingDate(LocalDate stockListingDate) {
	this.stockListingDate = stockListingDate;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public double getDiscount() {
	return discount;
}

public void setDiscount(double discount) {
	this.discount = discount;
}

@Override
public String toString() {
	return "Pen [id=" + id + ", brand=" + brand + ", inkColor=" + inkColor + ", meterial=" + meterial + ", stock="
			+ stock + ", stockUpdateDate=" + stockUpdateDate + ", stockListingDate=" + stockListingDate + ", price="
			+ price + ", discount=" + discount + "]";
}
	
	
	
}
