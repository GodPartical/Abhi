package cricketer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class CricketTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Cricketer> listCricketer=new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		for(int i=1;i<=5;i++) {
			System.out.println("Enter the name age emailId phone rating");
//			String name, int age, String emailId, String phone, int rating
			Cricketer cricketer=new Cricketer(sc.next(), sc.nextInt(), sc.next(), sc.next(), sc.nextInt());
			listCricketer.add(cricketer);
		}
		
		System.out.println("Enter the name who want to modify :");
		String name2=sc.next();
		for(Cricketer cricket : listCricketer) {
			if(cricket.getName().equalsIgnoreCase(name2)) {
				System.out.println("please updated rating : ");
				cricket.setRating(sc.nextInt());
				break;
			}
		}
		System.out.println();
		
		System.out.println("Enter the name of cricketer who you want to search : ");
		String name=sc.next();
		for(Cricketer cricket: listCricketer) {
			if(cricket.getName().equalsIgnoreCase(name)) {
				System.out.println(cricket);
			}
		}
		
		System.out.println();
		//display all
		System.out.println("Display all cricketers");
		for(Cricketer cricket: listCricketer) {
			System.out.println(cricket);
		}
		System.out.println();
		//sort by rating
		System.out.println("Serching all by its rating");
		Collections.sort(listCricketer, new Comparator<Cricketer>() {

			@Override
			public int compare(Cricketer o1, Cricketer o2) {
				// TODO Auto-generated method stub
				return Integer.compare(o1.getRating(), o2.getRating());
			}
		});
		
		for(Cricketer cricket : listCricketer) {
			System.out.println(cricket);
		}
		
	}

}
