package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import entity.Employee;
import validation.EmployeeValidation;

public class EmployeeTest {

	public static void main(String[] args) {
		List<Employee> employee=new ArrayList<>();
		Scanner sc=new Scanner(System.in);
		String ch="";
		EmployeeValidation employeeValidation=new EmployeeValidation();
		do {
			System.out.println("Menu:");
            System.out.println("1. Add full time employee");
            System.out.println("2. Add part time employee");
            System.out.println("3. Delete an employee by Emp Id");
            System.out.println("4. Search employee details by Aadhaar number");
            System.out.println("5. Display all employee details");
            System.out.println("6. Display all employee details sorted by date of joining");
            System.out.println("7. Exit");
            int choice=sc.nextInt();
            switch (choice) {
			case 1: 
				employeeValidation.addFullEmployee(employee, sc);
				break;
			case 2:
				employeeValidation.addPartEmployee(employee, sc);
				break;
			case 3:
				employeeValidation.deleteEmployee(employee, sc);
				break;
			case 4:
				employeeValidation.serchByAadhar(employee, sc);
				break;
			case 5:
				employeeValidation.displayAllEmployee(employee, sc);
				break;
			case 6:
				employeeValidation.displayAllSortedEmployeeByDateOfJoining(employee, sc);
				break;
			case 7:
				break;
			default:
				System.out.println("you click wrong Inpute try again ....");
				break;	
			}
			System.out.println("If you want to continue please press y :");
			ch=sc.next();
		}while(ch.equalsIgnoreCase("y"));
		
	}

}
