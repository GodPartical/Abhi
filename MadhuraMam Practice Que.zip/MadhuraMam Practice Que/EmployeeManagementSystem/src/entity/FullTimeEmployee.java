package entity;

import java.time.LocalDate;

public class FullTimeEmployee extends Employee{
	
	private double monthSalary;
	
	public FullTimeEmployee(String name, LocalDate dateOfJoining, String phNo, String aadharNo, double monthSalary) {
		super(name, dateOfJoining, phNo, aadharNo);
		this.monthSalary=monthSalary;
	}

	public double getMonthSalary() {
		return monthSalary;
	}

	public void setMonthSalary(double monthSalary) {
		this.monthSalary = monthSalary;
	}

	@Override
	public String toString() {
		return "FullTimeEmployee [monthSalary=" + monthSalary +", "+super.toString() + "]";
	}

	
}
