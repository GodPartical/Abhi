package entity;

import java.time.LocalDate;

public class Employee {
	private static int count;
	private int empId;
	private String name;
	private LocalDate dateOfJoining;
	private String phNo;
	private String aadharNo;
	
	public Employee(String name, LocalDate dateOfJoining, String phNo, String aadharNo) {
		super();
		this.empId = ++count;
		this.name = name;
		this.dateOfJoining = dateOfJoining;
		this.phNo = phNo;
		this.aadharNo = aadharNo;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getPhNo() {
		return phNo;
	}

	public void setPhNo(String phNo) {
		this.phNo = phNo;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", dateOfJoining=" + dateOfJoining + ", phNo=" + phNo
				+ ", aadharNo=" + aadharNo + "]";
	}
	
	
}
