package entity;

import java.time.LocalDate;

public class PartTimeEmployeee extends Employee{
	
	private double hourlyPayment;
	
	public PartTimeEmployeee(String name, LocalDate dateOfJoining, String phNo, String aadharNo, double hourlyPayment) {
		super(name, dateOfJoining, phNo, aadharNo);
		this.hourlyPayment=hourlyPayment;
	}

	public double getHourlyPayment() {
		return hourlyPayment;
	}

	public void setHourlyPayment(double hourlyPayment) {
		this.hourlyPayment = hourlyPayment;
	}

	@Override
	public String toString() {
		return "PartTimeEmployeee [hourlyPayment=" + hourlyPayment +", "+super.toString() + "]";
	}

	
	
	
}
