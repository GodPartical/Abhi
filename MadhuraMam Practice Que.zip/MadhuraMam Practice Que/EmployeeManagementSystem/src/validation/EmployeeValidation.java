package validation;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

import entity.Employee;
import entity.FullTimeEmployee;
import entity.PartTimeEmployeee;

public class EmployeeValidation {

	public void addFullEmployee(List<Employee> employee, Scanner sc) {
		System.out.println("enter name dateOfJoining phNo aadharNo");
		String name=sc.next();
		LocalDate dateOfJoining=LocalDate.parse(sc.next());
		String phoneNo=sc.next();
		String aadharNumber=sc.next();
		if(aadharExists(aadharNumber, employee)) {
			System.out.println("Aadhar number is alrady Exists");
			return;
		}
		System.out.println("enter month sal :");
		double monthlySalary=sc.nextDouble();
		FullTimeEmployee fullTimeEmployee=new FullTimeEmployee(name, dateOfJoining, phoneNo, aadharNumber, monthlySalary);
		employee.add(fullTimeEmployee);
		System.out.println("full time employee added....");
	}
	private static boolean aadharExists(String aadharNumber, List<Employee> employee) {
		return employee.stream().anyMatch(e -> e.getAadharNo().equals(aadharNumber));
		
	}
	public void addPartEmployee(List<Employee> employee, Scanner sc) {
		System.out.println("enter name dateOfJoining phNo aadharNo");
		String name=sc.next();
		LocalDate dateOfJoining=LocalDate.parse(sc.next());
		String phoneNo=sc.next();
		String aadharNumber=sc.next();
		if(aadharExists(aadharNumber, employee)) {
			System.out.println("Aadhar number is alrady Exists");
			return;
		}
		System.out.println("enter hurly sal :");
		double hourlySalary=sc.nextDouble();
		PartTimeEmployeee partTimeEmployee=new PartTimeEmployeee(name, dateOfJoining, phoneNo, aadharNumber, hourlySalary);
		employee.add(partTimeEmployee);
		System.out.println("Part time employee added....");
	}

	public void deleteEmployee(List<Employee> employee, Scanner sc) {
		System.out.println("Enter employee Id to delete : ");
		int eid=sc.nextInt();
//		employee=employee.stream()
//				.filter(e -> e.getEmpId()!=eid)
//				.collect(Collectors.toList());
		employee.removeAll(employee.stream().filter(e -> e.getEmpId()==eid).collect(Collectors.toList()));
		System.out.println("Employee deleted successfully .....");
		
	}

	public void serchByAadhar(List<Employee> employee, Scanner sc) {
		System.out.println("Enter Aadhar No to search : ");
		String aadharNumber=sc.next();
		Optional<Employee> empOptional=employee.stream()
				.filter(e -> e.getAadharNo().equals(aadharNumber))
				.findFirst();
		if(empOptional.isPresent()) {
			System.out.println(empOptional.get());
		}else {
			System.out.println("Employee is not there");
		}
	}

	public void displayAllEmployee(List<Employee> employee, Scanner sc) {
		employee.forEach(System.out::println);
	}

	public void displayAllSortedEmployeeByDateOfJoining(List<Employee> employee, Scanner sc) {
	employee.stream()
	.sorted(Comparator.comparing(Employee::getDateOfJoining))
	.forEach(System.out::println);
		
	}
	
	
}
