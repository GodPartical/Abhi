package com.app.custome_exception;

@SuppressWarnings("serial")
public class EmployeeCustomeExc extends Exception {
	public EmployeeCustomeExc(String msg) {
		super(msg);
	}
}
