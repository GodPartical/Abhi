package com.app.employee;

public enum EmpType {
	FTE,PTE
}
