package core;

import java.util.Objects;

public class Cricketer {

//	String name,int age,String email_id,String Phone,int rating
	
	private int age;
	private String name;
	private String email_id;
	private String phone;
	private int rating;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Cricketer [age=" + age + ", name=" + name + ", email_id=" + email_id + ", phone=" + phone + ", rating="
				+ rating + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cricketer other = (Cricketer) obj;
		return Objects.equals(email_id, other.email_id) && Objects.equals(name, other.name);
	}
	public Cricketer(int age, String name, String email_id, String phone, int rating) {
		super();
		this.age = age;
		this.name = name;
		this.email_id = email_id;
		this.phone = phone;
		this.rating = rating;
	}
	
	

	
	
	
}

