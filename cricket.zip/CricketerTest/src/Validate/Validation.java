package Validate;
import java.util.ArrayList;

import core.Cricketer;

public class Validation
{
	
	public static Cricketer create(int age, String name, String email_id, String phone, int rating) {
		
		if (phone.length()!= 10) {
			System.out.println("Invalid Phone");
			return null;
		}
		
		if(!(email_id.contains(".com"))) {
			
			System.out.println("Invalid email");
			return null;
		}
		
		return new Cricketer(age, name, email_id, phone, rating);
	}
	
	public static ArrayList <Cricketer> populate(){
		ArrayList<Cricketer > list = new ArrayList();
		
		list.add(new Cricketer(21, "sid", "sid.com", "123", 7));
		list.add(new Cricketer(22, "ram", "ram.com", "456", 9));
		list.add(new Cricketer(23, "yash", "yash.com", "789", 5));
		list.add(new Cricketer(24, "roshan", "roshan.com", "963", 6));
		list.add(new Cricketer(25, "abhi", "abhi.com", "741", 8));

		
		
		return list;
	}
	
	
	
	
	
	

}
