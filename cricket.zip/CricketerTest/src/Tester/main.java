package Tester;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

import Validate.Validation;
import core.Cricketer;

public class main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		boolean exit = false;
		
		ArrayList<Cricketer> list=Validation.populate();

		while (!exit) {
			System.out.println("case  0 - Exit , 1 - Add player , 2 - Display all players , 3 - Search by name & mail, 4 - reading list");

			switch (sc.nextInt()) {
			case 0: {
				exit = true;
				break;
			}

			case 1:{
				System.out.println("enter the following details -age , name, email_id,  phone,  rating");
			//	list.add(new Cricketer(sc.nextInt(), sc.next(), sc.next(),sc.next(), sc.nextInt()));
				list.add(Validation.create(sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.nextInt()));
				System.out.println("player added successfully");
				break;
			}
			
			case 2 :{
				
				for(Cricketer a : list) {
				System.out.println(a);
				}
				
				break;
			}
			
			case 3: {
				System.out.println("in case 3");
				System.out.println("Enter name and email to find player");
				for (Cricketer b : list) {
					
					if(b.getName().equals(sc.nextLine()) && b.getEmail_id().equals(sc.nextLine())) {
						System.out.println(b);
					}
					else {
						System.out.println("Not found ");
					}
				}
				
				
				
				break;
			}
			
			case 4 :{
				System.out.println("in case 4");
				System.out.println("Enter name & email");
				String name = sc.next();
				System.out.println("Enter the emmail");
				String email = sc.next();
				list.stream().filter(i -> i.getName().equals(name)).filter(i -> i.getEmail_id().equals(email)).forEach(i -> System.out.println(i));
				
				
				
				break;
			}
			
			case 5 :{
				
				System.out.println("In case 5");
				
				String name = sc.next();
				String email = sc.next();
				int rate = sc.nextInt();
				
				list.stream().filter(i -> i.getName().equals(name)).filter(i -> i.getEmail_id().equals(email)).forEach (i -> i.setRating(rate));
				
				break;
			}
			
			case 6 : {
				
				System.out.println("In case 6");
				String name = sc.next();

				String email = sc.next();
				
				for(Cricketer a : list) {
					
					if( a.getEmail_id().equals(email)&& a.getName().equals(name)) {
						list.remove(a);
						break;
						
					}
					
				}
				
				break;
			}
			
			case 7: {
		//	Comparator<Cricketer> LambdaLoNaMera = (a,b) -> a.getName().compareTo(b.getName());
				Comparator<Cricketer>Lambda = (i,j) -> ((Integer)i.getRating()).compareTo(j.getRating());
				list.stream().sorted(Lambda).forEach(i -> System.out.println(i));
				break;
			}
			
			
			
			}

		}
		

	}
}
