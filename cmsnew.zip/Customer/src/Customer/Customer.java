package Customer;

import java.time.LocalDate;

public class Customer {

	private int id;
	private String Name;
	private String Mail;
	private LocalDate dob;
	private String password;
	private plan plan;

	public Customer(int id, String name, String mail, LocalDate dob, String password, plan plan) {
		super();
		this.id = id;
		Name = name;
		Mail = mail;
		this.dob = dob;
		this.password = password;
		this.plan = plan;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getMail() {
		return Mail;
	}
	public void setMail(String mail) {
		Mail = mail;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public plan getPlan() {
		return plan;
	}
	public void setPlan(plan plan) {
		this.plan = plan;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", Name=" + Name + ", Mail=" + Mail + ", dob=" + dob + ", password=" + password
				+ ", plan=" + plan + "]";
	}
	
	
}
