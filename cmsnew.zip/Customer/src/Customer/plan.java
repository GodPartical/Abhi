package Customer;

public enum plan {

	GOLD, SILVER;
	
}
