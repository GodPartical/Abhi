package Tester;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

import Customer.Customer;
import Validation.validate;

public class Tester2 {

	public static void main(String[] args) {

		ArrayList<Customer> list=new ArrayList<Customer>();
		Scanner sc = new Scanner(System.in);
		boolean exit = false;
		while (!exit) {

			System.out.println("0.Exit");
			System.out.println("1.Add");
			System.out.println("2.Display");
			System.out.println("3.Read");
			System.out.println("4.Update");
			System.out.println("5.Sort by Name");
			System.out.println("6.Remove by Id");
			

			switch (sc.nextInt()) {

			case 0: {
				exit = true;
				System.out.println("Application Closed");
				break;
			}

			case 1: {
				System.out.println("Enter Following Details - Id,Name,Email,Dob,Password, Plan");

				list.add(validate.addCustomer(sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.next(), sc.next()));

				break;
			}

			case 2: {

				validate.displayAll(list);

				break;
			}
			
			case 3 :{
				System.out.println("Enter Id to search");
				validate.findById(sc.nextInt(), list);
				
				break;
			}
			
			case 4:{
				System.out.println("Enter Id for searching and name to update");
				
				validate.updateName(sc.nextInt(), sc.next(), list);
				
				break;
			}
			
			case 5 :{
			System.out.println("Sort by Mail");
				Comparator<Customer>lambda=(i,j)-> i.getMail().compareTo(j.getMail());
				list.stream().sorted(lambda).forEach(i -> System.out.println(i));
				
			break;
			}
			
			case 6:{
			System.out.println("Remove By Id");
			System.out.println("Enter Id To remove");
			int id=sc.nextInt();
			list.removeIf(i->i.getId()==id);
			
			break;
			}
			}
		}
	}

}
