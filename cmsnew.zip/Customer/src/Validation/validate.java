package Validation;

import java.time.LocalDate;
import java.util.ArrayList;

import Customer.Customer;
import Customer.plan;

public class validate {
	
	
//	public static ArrayList<Customer>populateList(){
//	 ArrayList<Customer> list=new ArrayList<Customer>();
//	
//	 list.add(new Customer(101, "sid", "sid.com",  LocalDate.parse("2001-09-09"), "sid123", plan.GOLD));
//	 list.add(new Customer(202, "ram", "ram.com",  LocalDate.parse("2002-08-08"), "sid123", plan.SILVER));
//	 list.add(new Customer(303, "abhi", "abhi.com",  LocalDate.parse("2003-07-07"), "sid123", plan.GOLD));
//	 list.add(new Customer(404, "guru", "guru.com",  LocalDate.parse("2004-06-06"), "sid123", plan.SILVER));
//	 list.add(new Customer(505, "sarang", "sarang.com",  LocalDate.parse("2005-05-05"), "sid123", plan.GOLD));
//	 list.add(new Customer(606, "vishal", "vishal.com",  LocalDate.parse("2006-04-04"), "sid123", plan.GOLD));
//	 
//		return list;
	//}

	public static Customer addCustomer(int id, String name, String mail, String dob, String password, String x) {

		LocalDate d = LocalDate.parse(dob);
		plan p = plan.valueOf(x.toUpperCase());

		return new Customer(id, name, mail, d, password, p);

	}

	public static void displayAll(ArrayList<Customer> list) {

		for (Customer a : list) {
			System.out.println(a);
		}

	}

	public static void findById(int id, ArrayList<Customer> list) {

		for (Customer a : list) {
			if (a.getId() == id) {
				System.out.println("Your Result");
				System.out.println(a);

			}

		}

	}

	public static void updateName(int id, String name, ArrayList<Customer> list) {

		for (Customer a : list) {

			if (a.getId() == id) {
				a.setName(name);
				System.out.println("name updated");
			}
		}

	}
	

}
