package CMS;

public enum Plan {
	
	GOLD,SILVER;

}
