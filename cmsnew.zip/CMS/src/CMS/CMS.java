package CMS;

import java.time.LocalDate;
import java.util.Objects;

public class CMS {

	private int id;
	private String name;
	private String mail;
	private String password;
	private LocalDate Dob;
	private Plan plan;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDate getDob() {
		return Dob;
	}

	public void setDob(LocalDate dob) {
		Dob = dob;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	@Override
	public String toString() {
		return "CMS [id=" + id + ", name=" + name + ", mail=" + mail + ", password=" + password + ", Dob=" + Dob
				+ ", plan=" + plan + "]";
	}

	public CMS(int id, String name, String mail, String password, LocalDate dob, Plan plan) {
		super();
		this.id = id;
		this.name = name;
		this.mail = mail;
		this.password = password;
		Dob = dob;
		this.plan = plan;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CMS other = (CMS) obj;
		return id == other.id;
	}

}
