package Validations;

import java.time.LocalDate;
import java.util.ArrayList;

import CMS.CMS;
import CMS.Plan;


public class Validate {
	public static int id = 1;

	public static ArrayList<CMS>populateList(){
		 ArrayList<CMS> list=new ArrayList<CMS>();
		
		 list.add(new CMS(101, "sid", "sid.com",  "sid123", LocalDate.parse("2001-09-09"), Plan.GOLD));
		 list.add(new CMS(102, "ram", "ram.com",  "ram123", LocalDate.parse("2001-08-08"), Plan.SILVER));
		 list.add(new CMS(103, "abhi", "abhi.com",  "abhi123", LocalDate.parse("2001-07-07"), Plan.GOLD));
		 list.add(new CMS(104, "guru", "guru.com",  "guru23", LocalDate.parse("2001-06-06"), Plan.SILVER));

			return list;
		}


	public static CMS addCms( String name, String mail, String password,String dob, String plan) {
		LocalDate d = LocalDate.parse(dob);
		Plan p = Plan.valueOf(plan.toUpperCase());
		if(validateemail(mail) ) {
			return new CMS(id++, name, mail, password, d, p);
		}
		else {
			System.out.println("invalid email");
			return null;
		}
		
		
	}

	public static void  displayAll(ArrayList<CMS>list) {
		for (CMS a : list) {
			
			System.out.println(a);
		}
	}
	public static void findById(int id,ArrayList<CMS>list) {
		
		for (CMS a : list) {
			if(a.getId()==id) {
				System.out.println("Your Result");
				System.out.println(a);
			}
		}
	}
	
	public static void updateName(int id , String name , ArrayList<CMS>list) {
		
		for ( CMS a : list) {
			if(a.getId()==id) {
				a.setName(name);
				System.out.println("Name Updated");
			}
		}
	}
	public static boolean validateemail(String email) {
		if(email.length() >= 8 && email.contains(".com") ) {
			return true;
		}
		
		
		return false;
	}
}
