package Tester;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

import CMS.CMS;
import Validations.Validate;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		ArrayList<CMS> list = Validate.populateList();
		boolean exit = false;
		while (!exit) {

			System.out.println("0.Exit");
			System.out.println("1.Add");
			System.out.println("2.Display");
			System.out.println("3.Read");
			System.out.println("4.Update");
			System.out.println("5.Sort by Name");
			System.out.println("6.Remove by Id");

			switch (sc.nextInt()) {

			case 0: {
				exit = true;
				System.out.println("App Closed");
				break;
			}

			case 1: {
				System.out.println("Enter Details- Id, Name, Mail , Password, Dob , Plan");
				list.add(Validate.addCms( sc.next(), sc.next(), sc.next(), sc.next(), sc.next()));
				break;
			}

			case 2: {
				Validate.displayAll(list);
				break;
			}

			case 3: {
				System.out.println("Enter Id To  Find Customer");
				Validate.findById(sc.nextInt(), list);
				break;
			}
			case 4: {
				System.out.println("Enter ID to read and Name to Change ");
Validate.updateName(sc.nextInt(), sc.next(), list);
				break;
			}
			
			case 5 :{
				
				System.out.println("Sort by Mail");
//				Comparator<CMS>lambda=(i,j)->i.getMail().compareTo(j.getMail());
//				list.stream().sorted(lambda).forEach(i->System.out.println(i));
			
				Comparator<CMS>lambda=(i,j)->i.getMail().compareTo(j.getMail());
				list.stream().sorted(lambda).forEach(i->System.out.println(i));
				break;
				
			}
			case 6:{
				System.out.println("Enter Id to Remove");
				int id=sc.nextInt();
				list.removeIf(i->i.getId()==id);
				break;
			}
			}
		}
	}

}
