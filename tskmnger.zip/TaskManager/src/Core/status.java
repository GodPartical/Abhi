package Core;

public enum status {
	
	COMPLETED,PENDING , IN_PROGRESS;

}
