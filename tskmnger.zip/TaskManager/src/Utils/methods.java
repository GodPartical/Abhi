package Utils;

import java.time.LocalDate;
import java.util.ArrayList;
import Core.Task;
import Core.status;

public class methods {
	
	public static int id=0;
	
	public static Task createNewTask(String taskName,String description, 
			String taskDate ) {
	
		LocalDate d= LocalDate.parse(taskDate);
		
		return new Task(++id,taskName,description,d,status.PENDING,true);
	}
	
	
	public static ArrayList<Task> populateList(){
		
		ArrayList<Task> list =new ArrayList<>();
list.add (new Task(101,"college","study",LocalDate.parse("2024-01-01"),status.COMPLETED,false));
list.add (new Task(102,"college","lab",LocalDate.parse("2024-02-02"),status.COMPLETED,false));
list.add (new Task(103,"college","lecture",LocalDate.parse("2024-03-03"),status.COMPLETED,false));
list.add (new Task(104,"college","project",LocalDate.parse("2024-04-04"),status.COMPLETED,false));
list.add (new Task(105,"gym","run",LocalDate.parse("2024-05-05"),status.COMPLETED,false));
list.add (new Task(106,"gym","walk",LocalDate.parse("2024-06-05"),status.PENDING,false));
list.add (new Task(107,"car","drive",LocalDate.parse("2024-06-05"),status.PENDING,false));

			return list;
		
	}
	public static void updateStatus(int id,ArrayList<Task> list) {
		
		for (Task a : list) {
			if (a.getTaskId()==id) {
				a.setTaskStatus(status.COMPLETED);
				System.out.println(a);	
				
			}
		}
	}

}
