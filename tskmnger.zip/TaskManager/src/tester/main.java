package tester;

import java.util.ArrayList;

import Core.Task;
import Core.status;
import Utils.methods;

public class main {

	public static void main(String[] args) {

//		Task T1= methods.createNewTask("gym","exercise","2024-05-01");
//		System.out.println(T1);
//		Task T2= methods.createNewTask("gym","exercise","2024-05-01");
//		System.out.println(T2);
		
		ArrayList<Task>list=methods.populateList();
		
	//list.forEach(i->System.out.println(i));
		
		
//	list.stream().filter(i -> i.getTaskStatus() == status.PENDING).forEach(i -> System.out.println(i) );

		
		for(Task a : list) {
	if(a.getTaskStatus() == status.PENDING) {
		System.out.println(a);
	}
}
	
methods.updateStatus(106
	, list);		
	}
	
}
