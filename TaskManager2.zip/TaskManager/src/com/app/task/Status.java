package com.app.task;

public enum Status {
	PENDING,PROGRESS,COMPLETED
}
