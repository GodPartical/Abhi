package com.app.custome_exception;

public class CustomeExc extends Exception {
	public CustomeExc(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
