package com.app.store;

public enum PetCategory {
	CAT, DOG, RABBIT, FISH
}
