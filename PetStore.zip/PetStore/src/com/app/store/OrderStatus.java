package com.app.store;

public enum OrderStatus {
	PLACED,IN_PROCESS,COMPLETED
}
