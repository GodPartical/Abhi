package com.app.store;

public enum UserType {
	ADMIN,CUSTOMER
}
