package pen;

import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PenStore {
	private List<Pen> pen;

	public PenStore() {
		super();
		this.pen=new ArrayList<>();
	}

	public void addPen(Pen p) {
		pen.add(p);
		System.out.println("Add succefully");
	}
	
	public void update(int id,int stock) {
		for(Pen p : pen) {
			if(p.getId()==id) {
				p.setStock(stock);
				System.out.println("Stock updated...");
				return;
			}
		}
		System.out.println("Stock Not Updated!!!");
	}
	
	public void setDiscountForUnsoldPens() {
        LocalDate currentDate = LocalDate.now();
        for (Pen p : pen) {
            if (ChronoUnit.MONTHS.between(p.getStockUpdateDate(), currentDate) >= 3) {
                p.setDiscount(20.0);
            }
        }
        System.out.println("Discounts updated for unsold pens.");
    }
	
	
	public void removeNeverSoldPens() {
        LocalDate currentDate = LocalDate.now();
        Iterator<Pen> iterator = pen.iterator();
        while (iterator.hasNext()) {
            Pen pen = iterator.next();
            if (ChronoUnit.MONTHS.between(pen.getStockListingDate(), currentDate) >= 9) {
                iterator.remove();
            }
        }
        System.out.println("Removed pens that were never sold in the last 9 months.");
    }
	
	 public void displayPens() {
	        if (pen.isEmpty()) {
	            System.out.println("No pen available.");
	        } else {
	            for (Pen p : pen) {
	                System.out.println(p);
	            }
	        }
	 }
}
