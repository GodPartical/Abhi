package pen;

import java.time.LocalDate;
import java.util.Scanner;

public class Test {
	
	public static void main(String[] args) {
		/*
		1. Add new Pen
		2. Update stock of aPen
		3.Set discount of 20% for all the pens which are not at all sold in last 3 months
		4. Remove Pens which arenever sold once listed in 9 months
		*/
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		PenStore penStore=new PenStore();
		String ch="";
		int choice;
		do {
			System.out.println("1. Add new Pen");
			System.out.println("2.Update stock of a Pen");
			System.out.println("3.Set discount of 20% for all the pens "
					+ "which are not at all sold in last 3 months");
			System.out.println("4.Remove Pens which are never sold once listed in 9 months");
			System.out.println("5.display all pen");
			System.out.println("6.Exit");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
//				String brand, String inkColor, String meterial, int stock, 
//				LocalDate stockUpdateDate,
//				LocalDate stockListingDate, double price, double discount
				System.out.println("Enter the brand inkColor meterial stock updatedDate listedDate price discount");
				Pen pen=new Pen(sc.next(), sc.next(), sc.next(), sc.nextInt(), LocalDate.parse(sc.next()), LocalDate.parse(sc.next()), sc.nextDouble(), sc.nextDouble());
				penStore.addPen(pen);
				System.out.println("Done");
				break;
			case 2:
				System.out.println("Enter the id and stock");
				penStore.update(sc.nextInt(), sc.nextInt());
				break;
			case 3:
				System.out.println("discount for pen");
				penStore.setDiscountForUnsoldPens();
				break;
			case 4:
				System.out.println("remove the pen");
				penStore.removeNeverSoldPens();
				break;
			case 5:
				System.out.println("display all");
				penStore.displayPens();
				break;
			case 6:
				break;
			}
			
			
			System.out.println("Enter you want to Repet: y");
			ch=sc.next();
		}while(ch.equalsIgnoreCase("y"));

	}

}
