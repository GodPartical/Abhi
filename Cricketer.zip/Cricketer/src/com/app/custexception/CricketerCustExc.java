package com.app.custexception;


@SuppressWarnings("serial")
public class CricketerCustExc extends Exception{
	public CricketerCustExc(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
