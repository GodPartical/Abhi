package utils;

import java.time.LocalDate;

import core.BankStatement;

public class Validation {

	public static int TrId = 1;

	public static BankStatement CreateTransactionForDeposite(int acNo, String trDate, String narration, double dAmt) {

		LocalDate d = LocalDate.parse(trDate);
		return new BankStatement(acNo, TrId++, d, narration, 0, dAmt);

	}

	public static BankStatement CreateTransactionForWithdraw(int acNo, String trDate, String narration, double wAmt) {

		LocalDate d = LocalDate.parse(trDate);
		return new BankStatement(acNo, TrId++, d, narration, wAmt, 0);
	}
}
