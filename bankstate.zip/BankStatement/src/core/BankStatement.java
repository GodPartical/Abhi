package core;

import java.time.LocalDate;
import java.util.Objects;

public class BankStatement {

	private int AcNo;
	private int TrId;
	private LocalDate TrDate;
	private String Narration;
	private double WAmt;
	private double DAmt;
	
	public BankStatement(int acNo, int trId, LocalDate trDate, String narration, double wAmt, double dAmt) {
		super();
		AcNo = acNo;
		TrId = trId;
		TrDate = trDate;
		Narration = narration;
		WAmt = wAmt;
		DAmt = dAmt;
		
	}
	public int getAcNo() {
		return AcNo;
	}
	public void setAcNo(int acNo) {
		AcNo = acNo;
	}
	public int getTrId() {
		return TrId;
	}
	public void setTrId(int trId) {
		TrId = trId;
	}
	public LocalDate getTrDate() {
		return TrDate;
	}
	public void setTrDate(LocalDate trDate) {
		TrDate = trDate;
	}
	public String getNarration() {
		return Narration;
	}
	public void setNarration(String narration) {
		Narration = narration;
	}
	public double getWAmt() {
		return WAmt;
	}
	public void setWAmt(double wAmt) {
		WAmt = wAmt;
	}
	public double getDAmt() {
		return DAmt;
	}
	public void setDAmt(double dAmt) {
		DAmt = dAmt;
		
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankStatement other = (BankStatement) obj;
		return TrId == other.TrId;
	}
	@Override
	public String toString() {
		return "BankStatement [AcNo=" + AcNo + ", TrId=" + TrId + ", TrDate=" + TrDate + ", Narration=" + Narration
				+ ", WAmt=" + WAmt + ", DAmt=" + DAmt + " ]";
	}

	
	
	
	
}
