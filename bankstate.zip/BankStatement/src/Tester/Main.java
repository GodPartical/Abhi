package Tester;

import core.BankStatement;
import utils.Validation;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Enter - AcNo, TrDate , Narration , Amt");
		Scanner sc = new Scanner(System.in);
		ArrayList<BankStatement> list = new ArrayList<BankStatement>();
				

//		BankStatement A = utils.Validation.CreateTransactionForDeposite(sc.nextInt(), sc.next(), sc.next(),
//				sc.nextDouble());
//
//		System.out.println(A);
//		
//		
//		BankStatement B = utils.Validation.CreateTransactionForWithdraw(sc.nextInt(), sc.next(), sc.next(),
//				sc.nextDouble());
//
//	System.out.println(B);
//	
		boolean exit = false;
		while (!exit) {
			System.out.println("enter choice - 0. Exit  1. Deposite  2. Withdraw");
			switch (sc.nextInt()) {

			case 0: {
				exit = true;
				break;
			}
			case 1 : {
				
				list.add(Validation.CreateTransactionForWithdraw(sc.nextInt(),sc.next(),sc.next(), sc.nextDouble()));
				
			}
			
			}
		}

	}

}
