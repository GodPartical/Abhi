package core;

public enum plan {

	SILVER (500),GOLD (1000);

	private int charge;
	
	plan(int c ){
		
		this.charge=c;
		
	}

	public int getCharge() {
		return charge;
	}
	
	
	
}
