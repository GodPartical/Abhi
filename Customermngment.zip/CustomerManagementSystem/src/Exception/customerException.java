package Exception;

public class customerException extends Exception {

	
	public customerException(String e) {
		
		
		super (e);
	}
	
	
	
}
