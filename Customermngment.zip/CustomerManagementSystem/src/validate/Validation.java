package validate;

import java.time.LocalDate;

import Exception.customerException;
import core.Customer;
import core.plan;

public class Validation {

	public static Customer register(int custId, String fname, String lname, String plan, String dob, String email,
			String password, int charge) throws customerException {
		LocalDate d = parseDate(dob);
		plan p = ValidatePlan(plan, charge);
		String e = validateEmail(email);
		return new Customer(custId, fname, lname, p, d, email, password);
		

	}

	public static LocalDate parseDate(String date) {

		return LocalDate.parse(date);
	}

	public static plan ValidatePlan(String p, int c) throws customerException {

		plan x = plan.valueOf(p.toUpperCase());
		if (x.getCharge() != c) {
			throw new customerException("Invalid plan selection");
		}
		return x;
	}

	public static String validateEmail(String e) throws customerException {
		if (!e.contains("@gmail.com")) {

			throw new customerException("Invalid Email");

		}
		return e;
	}
	
	

}
