package Tester;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import core.Customer;

public class Main {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {

			ArrayList<Customer> list = new ArrayList();

			boolean exit = false;

			try {
				while (!exit) {

					System.out.println("0.Exit  1.RegisterCustomer   2.Login   3.Update password");

					switch (sc.nextInt()) {

					case 0: {

						exit = true;
						break;
					}

					
					case 1: {
						System.out.println("custId,firstName,LastName,Plan,Dob,email,password,charge");
						list.add(validate.Validation.register(sc.nextInt(), sc.next(), 
								sc.next(), sc.next(), sc.next(), sc.next(), sc.next(), sc.nextInt()));
						
						
						break;
					}
					
					case 2:{
						System.out.println("Enter email & password");
						String email= sc.next();
						String password = sc.next();
						
						for(Customer a :list) {
							
							if(a.getEmail().equals(email)&& a.getPassword().equals(password)) {
								System.out.println(a);

							}
							
							
						}
						
						break;
					}
					
					case 3:{
						System.out.println("Enter email & password");
						String email= sc.next();
						String password = sc.next();

						System.out.println("Enter new password");
						String newPassword = sc.next();
						
						for(Customer a : list) {
							
							if (a.getEmail().equals(email)&& a.getPassword().equals(password)) {
								a.setPassword(newPassword);
							}
						}
						
						
						break;
					}
					
					case 4:{
	for(Customer a : list) {
							
						System.out.println(a);
						}
						
						
					}
					}

				}

			}

			catch (Exception a) {
				sc.nextLine();
				System.out.println(a.getMessage());
			}
		}

	}

}
