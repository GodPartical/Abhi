package com.app.pen;

public enum PenMaterial {
	PLASTIC,ALLOY,STEEL,METAL
}
