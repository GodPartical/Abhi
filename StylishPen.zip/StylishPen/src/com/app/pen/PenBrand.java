package com.app.pen;

public enum PenBrand {
	CELLO, PARKER, REYNOLDS
}
