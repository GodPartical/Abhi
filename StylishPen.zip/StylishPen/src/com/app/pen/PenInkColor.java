package com.app.pen;

public enum PenInkColor {
	BLUE,BLACK,RED,GREEN
}
