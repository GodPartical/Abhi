package com.app.pen;

public enum PenColor {
	RED,BLUE,BLACK,WHITE,GREEN
}
