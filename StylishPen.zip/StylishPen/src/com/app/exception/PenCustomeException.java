package com.app.exception;


@SuppressWarnings("serial")
public class PenCustomeException extends Exception {
public PenCustomeException(String msg) {
	super(msg);
}
}
